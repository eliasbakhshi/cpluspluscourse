////#include "Lab1.h"
////#include "QueueLinkedListTemp.h"
////#include "Testing_functions.h"
////#include "Temp.h"
////#include <string>
////#include <iostream>
////#include <utility>
////#include "Lab3.h"
////#include "Stack.h"
//#include "IndexedList.hpp"
//#include <iostream>
//#include <string>
//#include <exception>
////
//using namespace std;
////
////
//int main() {
//	IndexedList<int> indexedList;
//	try {
//	indexedList.addAt(0, 55);
//	indexedList.addAt(0, 56);
//	indexedList.removeLast();
//	indexedList.addAt(0, 57);
//	indexedList.addAt(0, 58);
//	indexedList.addAt(2, 88);
//	} catch (const std::exception& e) {
//		cout << e.what() << endl;
//	}
//
//	cout << indexedList.size() << endl;
//
//
//	//	const int CAP = 9;
//	//	int aa[CAP]{ 77, 11, 33, 88, 99, 22, 44, 66, 55 };
//	//	//Countingsort(aa, CAP);
//	//	printArray(aa, CAP);
//	//
//	//	//selectionSort2(aa, CAP);
//	//
//	//	//cout << linearSearch2(aa, CAP, 55) << endl;
//	//	//cout << binarySearch2(aa, CAP, 55) << endl;
//	//	//cout << "binarySearchRec2 " << endl;
//	//	//cout << binarySearchRec2(aa, 0, CAP - 1, 22) << endl;
//	//
//	//
//	//	cout << "Start 2" << endl;
//	//	for (auto a : aa ) {
//	//		cout << a << " ";
//	//	}
//	//	cout << endl << "End 2" << endl;
//	//
//	//
//	//	/* QueueLinkedList */
//	//
//	//	cout << "QueueLinkedListTemp";
//	//
//	//	Queue<int> iQueue;
//	//	try {
//	//		iQueue.enqueue(22);
//	//		iQueue.enqueue(23);
//	//		iQueue.dequeue();
//	//	} catch (exception e) {
//	//		cout << e.what() << endl;
//	//	}
//	//
//	//	iQueue.printQueue();
//	//
//	//	//try {
//	//
//	//	//Stack <int> iStack;
//	//	//cout << "rrr" << endl;
//	//	//iStack.push(223423);
//	//	//cout << "rrr" << endl;
//	//	//cout << iStack.peek() << " yes <<";
//	//	//iStack.pop();
//	//	//cout << iStack.peek() << " yes <<";
//	//	//} catch (exception e) {
//	//	//	cout << e.what() << endl;
//	//	//}
//	//	
//	//
//	//
//
//	return 0;
//}
//
