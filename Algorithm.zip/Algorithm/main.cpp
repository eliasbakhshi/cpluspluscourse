//#pragma once
//#include <iostream>
//#include <exception>
//#include "BST.hpp"
//#include "Graph.hpp"
//#include "DisjointSets.hpp"
//#include <string>
//
//using namespace std; 
//
//int main() {
//
//	DisjointSets<string> disSets;
//
//	disSets.makeSet("a");
//	disSets.makeSet("b");
//	disSets.makeSet("c");
//
//	disSets.unionSet("a", "b");
//	disSets.unionSet("b", "c");
//
//	/*Graph<string> graph;
//
//	graph.addVertex("S");
//	graph.addVertex("K");
//
//	graph.addEdge("S", "K", 66);
//	vector<string> gv = graph.getAllNeighboursTo("S");
//	for (int i = 0; i < gv.size(); i++) {
//		cout << gv[i];
//	}*/
//
//
//	/*BST<int> bst;
//
//	bst.insert(55);
//	bst.insert(88);
//	bst.insert(99);
//	bst.insert(22);
//	bst.insert(90);
//
//	cout << bst.inOrderTraversal() << endl;
//	cout << bst.preOrderTraversal() << endl;
//	cout << bst.postOrderTraversal() << endl;
//	cout << bst.toGraphviz() << endl;*/
//
//	return 0;
//}	